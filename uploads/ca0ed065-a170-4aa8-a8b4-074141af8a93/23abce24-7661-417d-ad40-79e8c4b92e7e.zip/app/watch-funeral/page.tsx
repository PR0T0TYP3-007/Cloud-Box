import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent } from "@/components/ui/card"
import { Video, Clock, Globe, Users } from "lucide-react"

export default function WatchFuneralPage() {
  return (
    <main className="min-h-screen">
      <Header />

      <section className="py-24 md:py-32 bg-secondary/30">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-4xl mx-auto text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-light text-foreground mb-6 text-balance">
              Watch Funeral Services
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Unable to attend in person? We offer live streaming services so family and friends around the world can
              participate in the funeral service and pay their respects from anywhere.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto mb-16">
            <Card className="border-border hover:shadow-lg transition-shadow bg-background">
              <CardContent className="p-8">
                <div className="mb-4">
                  <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary/10">
                    <Video className="w-7 h-7 text-primary" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">Live Streaming</h3>
                <p className="text-muted-foreground leading-relaxed">
                  High-quality video and audio streaming of the funeral service in real-time. Share a private link with
                  family and friends who cannot attend in person.
                </p>
              </CardContent>
            </Card>

            <Card className="border-border hover:shadow-lg transition-shadow bg-background">
              <CardContent className="p-8">
                <div className="mb-4">
                  <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary/10">
                    <Clock className="w-7 h-7 text-primary" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">Recorded Service</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Access a recorded version of the service to watch later. Perfect for those in different time zones or
                  who need time to process their grief before viewing.
                </p>
              </CardContent>
            </Card>

            <Card className="border-border hover:shadow-lg transition-shadow bg-background">
              <CardContent className="p-8">
                <div className="mb-4">
                  <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary/10">
                    <Globe className="w-7 h-7 text-primary" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">Global Access</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Connect with loved ones anywhere in the world. Our streaming service works on all devices - computers,
                  tablets, and smartphones with a secure internet connection.
                </p>
              </CardContent>
            </Card>

            <Card className="border-border hover:shadow-lg transition-shadow bg-background">
              <CardContent className="p-8">
                <div className="mb-4">
                  <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary/10">
                    <Users className="w-7 h-7 text-primary" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">Easy to Use</h3>
                <p className="text-muted-foreground leading-relaxed">
                  No technical knowledge required. We provide simple instructions and a secure link. Click to watch -
                  it's that easy. Technical support available if needed.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="max-w-3xl mx-auto">
            <Card className="border-border bg-background/50">
              <CardContent className="p-8 md:p-12 text-center">
                <h2 className="text-2xl md:text-3xl font-light text-foreground mb-4">How It Works</h2>
                <div className="text-left space-y-4 text-muted-foreground leading-relaxed">
                  <div className="flex gap-4">
                    <span className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold">
                      1
                    </span>
                    <p>
                      <strong className="text-foreground">Book the Service:</strong> Let us know you'd like live
                      streaming when arranging the funeral.
                    </p>
                  </div>
                  <div className="flex gap-4">
                    <span className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold">
                      2
                    </span>
                    <p>
                      <strong className="text-foreground">Receive the Link:</strong> We'll provide a secure, private
                      link to share with your guests.
                    </p>
                  </div>
                  <div className="flex gap-4">
                    <span className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold">
                      3
                    </span>
                    <p>
                      <strong className="text-foreground">Watch Together:</strong> Guests click the link at the
                      scheduled time to watch the live service.
                    </p>
                  </div>
                  <div className="flex gap-4">
                    <span className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold">
                      4
                    </span>
                    <p>
                      <strong className="text-foreground">Access Recording:</strong> A recording is available for 30
                      days after the service.
                    </p>
                  </div>
                </div>

                <div className="mt-8 pt-8 border-t border-border">
                  <p className="text-lg text-muted-foreground mb-6">
                    Interested in live streaming for an upcoming service?
                  </p>
                  <a
                    href="/#contact"
                    className="inline-flex items-center justify-center rounded-md bg-primary text-primary-foreground px-8 py-3 text-base font-medium hover:bg-primary/90 transition-colors"
                  >
                    Contact Us to Learn More
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
