import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent } from "@/components/ui/card"
import { Users, Car, Music, HeartHandshake, UtensilsCrossed, Camera, FileText } from "lucide-react"

const services = [
  {
    icon: Users,
    title: "Pallbearers (Dressed to Specification)",
    description:
      "Fully trained and experienced professionals dressed in suits or traditional attires to walk beside the hearse, control the sympathizers when paying their last respect and carrying the casket where and when necessary to compliment the occasion.",
  },
  {
    icon: Car,
    title: "Hearse Services",
    description:
      "We have various luxury brands in our fleet of hearse like Executive Lincoln Jeep, R. Class 4matic Benz, Escalade Jeep, Hummer Jeep, Lincoln Navigator Jeep, Cadillac Limousine, Mercedes Benz, Bike Escort Service, Volvo amongst others.",
  },
  {
    icon: Music,
    title: "Mobile Brass Band and Live Band",
    description:
      "Professional musicians trained in the art of special melodic funeral music to make the burial a memorable one.",
  },
  {
    icon: HeartHandshake,
    title: "Professional Mourners",
    description:
      "Professionals in the area of sharing grievance and emotional pain of the deceased by crying and other ways of showing emotional pain during funeral service.",
  },
  {
    icon: UtensilsCrossed,
    title: "Catering Service",
    description: "We offer catering service. Our catering service also maintain any standard you want.",
  },
  {
    icon: Camera,
    title: "Photography and Video Recording",
    description:
      "We have experienced videographers and photographers that will provide you with professional shots that captures special moments during the funeral and delivered to you in any format of your choice.",
  },
  {
    icon: FileText,
    title: "Publications and Announcements",
    description:
      "We have professional graphic artists and copywriters that can create befitting obituary posters and announcements, IV Cards, Order-of-service, thank-you cards, etc for prints and electronic media.",
  },
]

export default function ServicesPage() {
  return (
    <main className="min-h-screen">
      <Header />

      <section className="py-24 md:py-32 bg-secondary/30">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-4xl mx-auto text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-light text-foreground mb-6 text-balance">Our Funeral Services</h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              We offer sensitive and compassionate burial arrangements. We also offer personalized services, including
              the casket, to reflect your loved ones' lifestyle, religion, tradition, profession, organizational
              affiliation.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed mt-4">
              At SYLVA-PAT Enterprises, our Funeral Directors will help you coordinate all the details required no
              matter what size during this time. Most importantly, our Funeral Directors will assist you in planning a
              personal and meaningful burial ceremony to begin the healing process.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {services.map((service, index) => {
              const Icon = service.icon
              return (
                <Card key={index} className="border-border hover:shadow-lg transition-shadow bg-background">
                  <CardContent className="p-8">
                    <div className="mb-4">
                      <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary/10">
                        <Icon className="w-7 h-7 text-primary" />
                      </div>
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-3">{service.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{service.description}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
