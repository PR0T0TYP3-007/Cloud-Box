"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Phone, Mail, MapPin, Clock } from "lucide-react"

export function Contact() {
  return (
    <section id="contact" className="py-24 md:py-32 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-light text-foreground mb-4 text-balance">We Are Here for You</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            {"Reach out to us anytime. We're available 24/7 to provide support and answer your questions."}
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Form */}
          <Card className="border-border">
            <CardContent className="p-8">
              <form className="space-y-6">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="firstName" className="block text-sm font-medium mb-2 text-foreground">
                      First Name
                    </label>
                    <Input id="firstName" placeholder="John" />
                  </div>
                  <div>
                    <label htmlFor="lastName" className="block text-sm font-medium mb-2 text-foreground">
                      Last Name
                    </label>
                    <Input id="lastName" placeholder="Smith" />
                  </div>
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium mb-2 text-foreground">
                    Email
                  </label>
                  <Input id="email" type="email" placeholder="john@example.com" />
                </div>

                <div>
                  <label htmlFor="phone" className="block text-sm font-medium mb-2 text-foreground">
                    Phone
                  </label>
                  <Input id="phone" type="tel" placeholder="+234 803 668 1993" />
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium mb-2 text-foreground">
                    Message
                  </label>
                  <Textarea id="message" placeholder="How can we help you?" rows={5} />
                </div>

                <Button
                  type="submit"
                  className="w-full bg-[oklch(0.65_0.15_85)] text-foreground hover:bg-[oklch(0.60_0.15_85)]"
                >
                  Send Message
                </Button>
              </form>
            </CardContent>
          </Card>

          <div className="space-y-8">
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[oklch(0.65_0.15_85)]/10">
                  <Phone className="w-5 h-5 text-[oklch(0.65_0.15_85)]" />
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-2">Phone</h3>
                <p className="text-muted-foreground">+234 803 668 1993</p>
                <p className="text-muted-foreground">+234 803 359 3159</p>
                <p className="text-muted-foreground">+234 805 463 5671</p>
                <p className="text-muted-foreground">+234 708 468 3633</p>
                <p className="text-muted-foreground">+234 817 787 1725</p>
                <p className="text-sm text-muted-foreground mt-1">Available 24/7</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[oklch(0.65_0.15_85)]/10">
                  <Mail className="w-5 h-5 text-[oklch(0.65_0.15_85)]" />
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-2">Email</h3>
                <p className="text-muted-foreground">info@sylvapat.com</p>
                <p className="text-muted-foreground">enquiry@sylvapat.com</p>
                <p className="text-sm text-muted-foreground mt-1">We respond within 24 hours</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[oklch(0.65_0.15_85)]/10">
                  <MapPin className="w-5 h-5 text-[oklch(0.65_0.15_85)]" />
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-2">Head Office</h3>
                <p className="text-muted-foreground">
                  1-2 CMO Plaza, Regina Caeli Hospital Road
                  <br />
                  Awka, Anambra State, Nigeria
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[oklch(0.65_0.15_85)]/10">
                  <Clock className="w-5 h-5 text-[oklch(0.65_0.15_85)]" />
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-2">Hours</h3>
                <p className="text-muted-foreground">
                  Office: Mon-Sat 8:00 AM - 6:00 PM
                  <br />
                  Emergency Services: 24/7
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-16 pt-16 border-t border-border">
          <h3 className="text-2xl font-light text-center mb-8">Our Branches</h3>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center">
              <h4 className="font-semibold mb-2">Awka Branch</h4>
              <p className="text-sm text-muted-foreground">
                Shop 54, CMO Plaza, Regina Caeli Hospital Road, Awka, Anambra State
              </p>
            </div>
            <div className="text-center">
              <h4 className="font-semibold mb-2">Adazi-Ani Branch</h4>
              <p className="text-sm text-muted-foreground">
                Nkpuota Junction, Adazi-Ani, Aniocha L.G.A., Anambra State
              </p>
            </div>
            <div className="text-center">
              <h4 className="font-semibold mb-2">Uga Branch</h4>
              <p className="text-sm text-muted-foreground">
                Christ the King Plaza, Nnewi Road, Uga, Aguata L.G.A., Anambra State
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
